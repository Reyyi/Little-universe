import type { Media } from "./types";

const sizes: Record<number, [number, number]> = {
  0: [1600, 1067],
  1: [1200, 1500],
  2: [1500, 1000],
  3: [1000, 1250],
  4: [1400, 1400],
};

/** Placeholder photo helper. Replace with real Media objects whenever you like. */
export function photo(n: number, alt: string): Media {
  const [width, height] = sizes[n % 5];
  return { src: `/media/photos/photo-${String(n).padStart(2, "0")}.jpg`, alt, width, height };
}
